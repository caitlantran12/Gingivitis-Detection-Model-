#!/usr/bin/env python3
"""Audit CSS2 mask quality, split sizes, class balance, and confidence files.

Run from anywhere:
    python tools/audit_dataset.py --root /path/to/CSS2
"""

from __future__ import annotations

import argparse
import json
import statistics
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image


SPLITS = ("Training", "Validation", "Test")
MASK_DIRS = ("MasksIndex", "SAM2_MasksIndex", "SAM2_Morph_MasksIndex")


def percentile(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    values = sorted(values)
    idx = int(q * (len(values) - 1))
    return values[idx]


def count_images(dataset_root: Path) -> None:
    print("Split sizes")
    for split in SPLITS:
        image_count = len(list((dataset_root / split / "Images").glob("*.jpg")))
        print(f"  {split:10s}: {image_count:4d} images")


def audit_masks(dataset_root: Path) -> None:
    for mask_dir in MASK_DIRS:
        print(f"\nPixel distribution: {mask_dir}")
        for split in SPLITS:
            paths = sorted((dataset_root / split / mask_dir).glob("*.png"))
            counts: Counter[int] = Counter()
            empty = 0

            for path in paths:
                arr = np.array(Image.open(path))
                values, value_counts = np.unique(arr, return_counts=True)
                file_counts = dict(zip(values.tolist(), value_counts.tolist()))
                counts.update(file_counts)

                labelled = sum(v for k, v in file_counts.items() if k != 255)
                if labelled == 0:
                    empty += 1

            total = sum(counts.values())
            valid = total - counts.get(255, 0)
            valid_pct = (100 * valid / total) if total else 0.0
            ignore_pct = (100 * counts.get(255, 0) / total) if total else 0.0

            class_parts = []
            for cls in sorted(k for k in counts if k != 255):
                pct = (100 * counts[cls] / valid) if valid else 0.0
                class_parts.append(f"{cls}:{pct:.1f}%")

            print(
                f"  {split:10s}: n={len(paths):4d}, empty={empty:3d}, "
                f"valid_px={valid_pct:4.1f}%, "
                f"{', '.join(class_parts)}, ignore={ignore_pct:4.1f}%"
            )


def audit_confidence(dataset_root: Path) -> None:
    print("\nSAM2 confidence files")
    for split in SPLITS:
        path = dataset_root / split / "sam2_confidence_scores.json"
        if not path.exists():
            print(f"  {split:10s}: missing")
            continue

        data = json.loads(path.read_text())
        values = [float(v) for v in data.values() if isinstance(v, (int, float))]

        if not values:
            print(f"  {split:10s}: no scalar confidence scores")
            continue

        print(
            f"  {split:10s}: n={len(values):4d}, "
            f"min={min(values):.3f}, q25={percentile(values, 0.25):.3f}, "
            f"median={percentile(values, 0.50):.3f}, "
            f"q75={percentile(values, 0.75):.3f}, max={max(values):.3f}, "
            f"mean={statistics.mean(values):.3f}"
        )


def audit_yolo_labels(root: Path) -> None:
    small_root = (
        root
        / "A DENTAL INTRAORAL IMAGE DATASET OF GINGIVITIS FOR IMAGE CAPTIONING"
        / "Dataset"
    )
    if not small_root.exists():
        return

    print("\nYOLO bounding-box label distribution")
    for split in SPLITS:
        labels = sorted((small_root / split / "Labels").glob("*.txt"))
        box_counts: Counter[str] = Counter()
        image_counts: Counter[str] = Counter()

        for path in labels:
            seen_in_file = set()
            for line in path.read_text(errors="ignore").splitlines():
                parts = line.split()
                if not parts:
                    continue
                cls = parts[0]
                box_counts[cls] += 1
                seen_in_file.add(cls)

            for cls in seen_in_file:
                image_counts[cls] += 1

        print(f"  {split:10s}: {len(labels):3d} label files")
        print(f"    boxes : {dict(sorted(box_counts.items()))}")
        print(f"    images: {dict(sorted(image_counts.items()))}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    args = parser.parse_args()

    root = args.root.expanduser().resolve()
    dataset_root = root / "CSS2_480p" / "Dataset"
    if not dataset_root.exists():
        raise SystemExit(f"Dataset root not found: {dataset_root}")

    print(f"Root: {root}")
    count_images(dataset_root)
    audit_masks(dataset_root)
    audit_confidence(dataset_root)
    audit_yolo_labels(root)


if __name__ == "__main__":
    main()
